﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AvalonDock;
using System.IO;
using System.Diagnostics;

namespace AvalonDockSampleProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            //var resPanel = new ResizingPanel() { Orientation = Orientation.Horizontal };
            //var dockPane = new DockablePane() { };
            //var documentPane = new DocumentPane() { };

            //dockPane.Items.Add(new DockableContent()
            //{
            //    Name = "classesContent",
            //    Title = "Classes"
            //});

            //documentPane.Items.Add(new DocumentContent()
            //{
            //    Title = "My Document!"
            //});

            //resPanel.Children.Add(dockPane);
            //resPanel.Children.Add(documentPane);
            //dockManager.Content = resPanel;

            dockManager.DeserializationCallback += (s, e) =>
            {
                //asserts that content that docking manager is looking for
                //is mynewContent
                Debug.Assert(e.Name == "mynewContent");

                var dockableContent = new DockableContent()
                {
                    Name = "mynewContent",
                    Title = "New Dock Content!"
                };

                //returns this new content 
                e.Content = dockableContent;
            };
        }

        private void CreateDocumentContent(object sender, RoutedEventArgs e)
        {
            var documentContent = new DocumentContent();
            documentContent.Title = "MyNewContent";
            documentContent.Show(dockManager);
        }

        private void CreateDockableContent(object sender, RoutedEventArgs e)
        {
            string name = "myNewContent";
            int i = 0;

            while (dockManager.DockableContents.Any(
                c => c.Name == "mynewContent"))
            {
                i++;
                name = "myNewContent" + i.ToString();
            }

            var dockableContent = new DockableContent()
            {
                Name = name,
                Title = string.Format("Title of {0}", name)
            };

            dockableContent.Show(dockManager);
        }

        const string LayoutFileName = "SampleLayout.xml";

        private void SaveLayout(object sender, RoutedEventArgs e)
        {
            dockManager.SaveLayout(LayoutFileName);
        }

        private void RestoreLayout(object sender, RoutedEventArgs e)
        {
            if (File.Exists(LayoutFileName))
                dockManager.RestoreLayout(LayoutFileName);
        }


    }
}
